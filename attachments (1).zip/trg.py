b=float(input("enter breadth:"))
h=float(input("enter height:"))
area=0.5*b*h
print("area of  equilateral triangle=",area)
