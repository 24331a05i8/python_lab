char=input("enter a character:")
ascii_value=ord(char)
print("the ascii value of ",char,"is",ascii_value)
