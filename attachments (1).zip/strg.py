a="hello"
b="siri"
c=a+" "+b
print(c)
